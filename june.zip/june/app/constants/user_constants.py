USERTYPE = (
    (0, "Super Admin"),
    (1, "Administrator"),
    (2, "Employee"),
    (3, "Client")
)

IS_ACTIVE = (
    (0, "NO"),
    (1, "YES"),
)

IS_TRUE = True
IS_FALSE = False



