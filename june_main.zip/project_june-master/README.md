# project_june
Freelancer Project In June 2020 for a firm. It is using Django and Pandas. Pandas is used to validate data in a Excel file, and then it is displayed in a html table. 

Few Operations:
  Create, Rename and Delete folders. Create Folders inside a Folder
  Upload Files to the folders created
  Validate Excel file which has a set of defined columns.
  Rename and Delete Files.
  
Upcoming Updates:
  Dynamic setting of columns for validation
  Support for CSV
  Move files and folders
  User Specific access on operations and events
  Pagination for huge datasets
  Dashboard for visualization
  Visualization of Data
